# Use the 'File' menu above to 'Save' after pasting in your 3 function calls.
